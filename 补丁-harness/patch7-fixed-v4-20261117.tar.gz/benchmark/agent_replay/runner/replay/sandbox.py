"""Shared E2B operations and replay bookkeeping, without client request throttling."""

from __future__ import annotations

import asyncio
import os
import re
import time
import uuid
from pathlib import Path
from typing import Any

from ...report.results import (
    SCHEMA_VERSION,
    TIMING_CONTRACT,
    absolute_timestamp,
    append_text,
    job_log_line,
    write_json,
)

from ..models import ReplayOptions, ReplayStep
from ..running_scheduler import RunningLease, RunningSlotScheduler
from .timeout_cleanup import CommandCleanupUncertain, CommandStartUncertain, terminate_command_tree
from .trajectory import (
    SUBMIT_ACTIONS,
    load_trajectory,
    normalize_str_replace_editor_action,
    wrap_action,
)


def exception_chain(exc: BaseException) -> list[dict[str, str]]:
    """Keep underlying client errors without changing command handling."""
    result = []
    seen = set()
    current: BaseException | None = exc
    while current is not None and id(current) not in seen and len(result) < 8:
        seen.add(id(current))
        result.append({"type": f"{type(current).__module__}.{type(current).__name__}",
                       "message": str(current)[:800]})
        current = current.__cause__ or (None if current.__suppress_context__ else current.__context__)
    return result


class SandboxRunner:
    """Common replay flow. Subclasses define initialization, each step and recovery."""

    execution_mode: str

    def __init__(
        self,
        trajectory_path: Path,
        output_dir: Path,
        options: ReplayOptions,
        *,
        running_slot_scheduler: RunningSlotScheduler,
        console_output: bool = False,
    ):
        self.trajectory_path = trajectory_path.resolve()
        self.output_dir = output_dir.resolve()
        self.options = options
        self.running_slot_scheduler = running_slot_scheduler
        self.console_output = console_output
        self.run_slot_task_id = self.output_dir.name
        self.sandbox: Any = None
        self.sandbox_id: str | None = None
        self.sandbox_create_key = uuid.uuid4().hex
        self._create_state_uncertain = False
        self._paused = False
        self._running_lease: RunningLease | None = None
        self._first_command_started_at = None
        self._first_command_started_monotonic = None
        self._last_command_completed_at = None
        self._last_command_completed_monotonic = None
        self._create_started_at = None
        self._create_completed_at = None
        self._create_started = None
        self._create_completed = None
        self._deleted_at = None
        self._deleted = None
        self._step_results: list[dict[str, Any]] = []
        self._api_timings: list[dict[str, Any]] = []
        self._last_timeout_cleanup: dict[str, Any] | None = None

    async def _api_call(self, operation: str, request: Any) -> Any:
        """Measure only the SDK await, before logging, parsing or retry handling."""
        started_at = absolute_timestamp()
        succeeded = False
        started = time.monotonic()
        try:
            value = await request
            succeeded = True
            return value
        finally:
            completed = time.monotonic()
            self._api_timings.append({
                "operation": operation,
                "started_at": started_at,
                "completed_at": absolute_timestamp(),
                "started_monotonic": started,
                "completed_monotonic": completed,
                "elapsed_sec": completed - started,
                "succeeded": succeeded,
            })

    def _api_total(self, operation: str) -> float:
        return sum(x["elapsed_sec"] for x in self._api_timings
                   if x["operation"] == operation)

    def _event(self, level: str, message: str) -> None:
        line = job_log_line(level, message)
        append_text(self.output_dir / "run.log", line)
        append_text(self.output_dir / "job.log", line)
        if self.console_output:
            print(line, flush=True)

    def _job_event(
        self, level: str, message: str, *, timestamp: str | None = None
    ) -> None:
        append_text(
            self.output_dir / "job.log",
            job_log_line(level, message, timestamp=timestamp),
        )

    def _block(self, text: str) -> None:
        append_text(self.output_dir / "run.log", text)
        if self.console_output:
            print(text, flush=True)

    async def _release_if_safe(self) -> None:
        if self._running_lease is not None and (
            self._paused or (self.sandbox is None and not self._create_state_uncertain)
        ):
            await self._running_lease.release()
            self._running_lease = None

    async def _find_sandboxes_by_create_key(self) -> list[Any]:
        from e2b import AsyncSandbox
        from e2b.sandbox.sandbox_api import SandboxQuery

        paginator = AsyncSandbox.list(
            query=SandboxQuery(metadata={"replay_create_key": self.sandbox_create_key}),
            limit=100,
        )
        matches = []
        while paginator.has_next:
            matches.extend(await self._api_call("create_lookup", paginator.next_items()))
        return matches

    async def _recover_created(self, matches: list[Any]) -> bool:
        raise NotImplementedError

    async def _reconcile_ambiguous_create(self) -> bool:
        empty_checks = 0
        last_error = None
        for check in range(3):
            # Bounded reconciliation, independent of the removed rate limiter.
            if check:
                await asyncio.sleep(1)
            try:
                matches = await asyncio.wait_for(
                    self._find_sandboxes_by_create_key(),
                    self.options.request_timeout_sec,
                )
            except Exception as exc:
                last_error = exc
                self._event("warning", f"Create reconciliation query failed: {exc!r}")
                continue
            if matches:
                matches.sort(
                    key=lambda item: (
                        str(getattr(item, "started_at", "")),
                        item.sandbox_id,
                    )
                )
                return await self._recover_created(matches)
            empty_checks += 1
            if empty_checks == 2:
                return False
        raise RuntimeError(
            f"Cannot reconcile create key {self.sandbox_create_key}"
        ) from last_error

    async def _create_sandbox(self) -> None:
        from e2b import AsyncSandbox

        self._create_started_at = absolute_timestamp()
        self._create_started = time.perf_counter()
        for attempt in range(self.options.create_retries + 1):
            self._create_state_uncertain = True
            try:
                self.sandbox = await self._api_call("create", AsyncSandbox.create(
                    template=self.options.template,
                    metadata={
                        "runner": "agent-workload-benchmark-suite",
                        "execution_mode": self.execution_mode,
                        "trajectory": self.trajectory_path.name,
                        "replay_create_key": self.sandbox_create_key,
                    },
                    timeout=self.options.sandbox_timeout_sec,
                    request_timeout=self.options.request_timeout_sec,
                    envs=({"GOPROXY": os.environ["AWBS_SANDBOX_GOPROXY"]}
                          if os.environ.get("AWBS_SANDBOX_GOPROXY") else None),
                ))
                self.sandbox_id = self.sandbox.sandbox_id
                self._create_state_uncertain = False
                break
            except asyncio.CancelledError:
                # A cancelled create may still finish remotely. Reconcile before cleanup.
                try:
                    await self._reconcile_ambiguous_create()
                except Exception as exc:
                    self._event("error", f"Cancelled create reconciliation: {exc!r}")
                raise
            except Exception as exc:
                self._event("warning", f"Create attempt {attempt + 1} failed: {exc!r}; "
                            f"exception_chain={exception_chain(exc)!r}")
                wait_ready = re.search(
                    r"\b500: sandbox ([0-9a-fA-F-]{36}) operation WaitReady failed:",
                    str(exc),
                )
                if wait_ready:
                    self.sandbox_id = wait_ready.group(1)
                    await asyncio.wait_for(
                        self._api_call("create_cleanup_delete", AsyncSandbox.kill(self.sandbox_id)),
                        self.options.request_timeout_sec,
                    )
                    self._create_state_uncertain = False
                    if attempt >= self.options.create_retries:
                        raise
                    await asyncio.sleep(2)
                    continue
                if is_timeout_error(exc) or is_transient_sandbox_error(exc):
                    if await self._reconcile_ambiguous_create():
                        break
                    # A timeout with no visible match is still ambiguous: never retry it.
                    if is_timeout_error(exc):
                        raise RuntimeError(
                            f"Create timed out; refusing duplicate create for key {self.sandbox_create_key}"
                        ) from exc
                    self._create_state_uncertain = False
                    if attempt < self.options.create_retries:
                        await asyncio.sleep(1)
                        continue
                else:
                    # Retain uncertainty for unexpected server errors; a definite 4xx
                    # rejection does not represent a successfully created sandbox.
                    if re.search(
                        r"\b40[0134]\b|unauthorized|forbidden|not found", str(exc), re.I
                    ):
                        self._create_state_uncertain = False
                raise
        self._create_completed = time.perf_counter()
        self._create_completed_at = absolute_timestamp()
        self._event("info", f"Created sandbox {self.sandbox_id} "
                    f"create_attempts={attempt + 1} elapsed={self._api_total('create'):.3f}s")

    async def _delete_sandbox(self) -> None:
        if self.sandbox is not None:
            await asyncio.wait_for(
                self._api_call("delete", self.sandbox.kill()), self.options.request_timeout_sec
            )
            timing = self._api_timings[-1]
            self._deleted = timing["completed_monotonic"]
            self._deleted_at = timing["completed_at"]
            self.sandbox = None
            self._paused = False
            self._create_state_uncertain = False
            self._event("info", f"Deleted sandbox {self.sandbox_id} "
                        f"elapsed={self._api_total('delete'):.3f}s")

    async def _cleanup(self) -> None:
        try:
            await self._delete_sandbox()
            if self._create_state_uncertain:
                raise RuntimeError(
                    f"Create outcome is uncertain; key={self.sandbox_create_key}"
                )
        except BaseException:
            await self.running_slot_scheduler.close()
            raise
        finally:
            # A successful delete may be followed by a failed log write.
            await self._release_if_safe()

    async def _initialize(self) -> None:
        raise NotImplementedError

    async def _run_step(
        self, step: ReplayStep, total: int, trajectory_total: int
    ) -> dict[str, Any]:
        raise NotImplementedError

    async def run(self) -> dict[str, Any]:
        # Match the original task clock: parse inputs before starting replay timing.
        environment, instance_id, steps = load_trajectory(self.trajectory_path)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        started = time.perf_counter()
        result: dict[str, Any] = {
            "schema_version": SCHEMA_VERSION,
            "execution_mode": self.execution_mode,
            "trajectory_path": str(self.trajectory_path),
            "template": self.options.template,
            "started_at": absolute_timestamp(),
            "command_timeout_sec": self.options.command_timeout_sec,
            "command_timeout_continue": self.options.command_timeout_continue,
            "replay_completed": False,
            "succeeded": False,
            "submitted": False,
            "stopped_early": False,
            "cleanup_succeeded": False,
            "steps": self._step_results,
            "timing_contract": TIMING_CONTRACT,
            "api_timings": self._api_timings,
        }
        self._event("info", f"Replay started trajectory={self.trajectory_path}")
        cancelled = False
        try:
            terminal = next(
                (
                    i
                    for i, step in enumerate(steps)
                    if step.action.lower() in SUBMIT_ACTIONS
                ),
                None,
            )
            executable = steps if terminal is None else steps[:terminal]
            if terminal is not None:
                self._event("info", f"Terminal action at position {terminal + 1}; "
                            f"executable commands={len(executable)} trajectory actions={len(steps)}")
            result.update(
                environment=environment,
                instance_id=instance_id,
                trajectory_actions=len(steps),
                executable_actions=len(executable),
                terminal_action_position=None if terminal is None else terminal + 1,
            )
            self._running_lease = await self.running_slot_scheduler.acquire(
                self.run_slot_task_id + ":prepare"
            )
            result["initial_running_slot_queue_wait_sec"] = (
                self._running_lease.queue_wait_sec
            )
            await self._create_sandbox()
            await self._initialize()
            for step in executable:
                item = await self._run_step(step, len(executable), len(steps))
                # Modes record a command immediately, even if the following pause fails.
                if item not in self._step_results:
                    self._step_results.append(item)
                if item["infrastructure_error"]:
                    raise RuntimeError(
                        f"Command infrastructure failed: {item['stderr']}"
                    )
                if item["timed_out"] and not self.options.command_timeout_continue:
                    raise TimeoutError(f"Command timed out at step {step.index + 1}")
                if (
                    self.options.stop_on_error
                    and not item["succeeded"]
                    and not item["timed_out"]
                ):
                    result["stopped_early"] = True
                    break
            result["replay_completed"] = not result["stopped_early"]
            result["succeeded"] = result["replay_completed"]
            result["submitted"] = terminal is not None and result["replay_completed"]
        except asyncio.CancelledError:
            cancelled = True
            result["error"] = "Replay cancelled"
            self._event("error", "Replay failed: Replay cancelled")
        except Exception as exc:
            result["error"] = f"{type(exc).__name__}: {exc}"
            self._event("error", f"Replay failed: {result['error']}")
        finally:
            # Preserve partial results before potentially slow cleanup.
            result.update(
                sandbox_id=self.sandbox_id,
                create_key=self.sandbox_create_key,
                commands=len(self._step_results),
                elapsed_sec=time.perf_counter() - started,
            )
            write_error: Exception | None = None
            try:
                write_json(self.output_dir / "replay-result.json", result)
            except Exception as exc:
                # Preserve the exception, but never let it skip sandbox cleanup.
                write_error = exc
            cleanup_task = asyncio.create_task(self._cleanup())
            try:
                await asyncio.shield(cleanup_task)
                result["cleanup_succeeded"] = True
            except asyncio.CancelledError:
                cancelled = True
                result["error"] = "Replay cancelled during cleanup"
                try:
                    await cleanup_task
                    result["cleanup_succeeded"] = True
                except Exception as exc:
                    result["cleanup_error"] = f"{type(exc).__name__}: {exc}"
            except Exception as exc:
                result["cleanup_error"] = f"{type(exc).__name__}: {exc}"
            result["succeeded"] = (
                result["succeeded"] and result["cleanup_succeeded"] and not cancelled
            )
            result.update(
                completed_at=absolute_timestamp(),
                elapsed_sec=time.perf_counter() - started,
                succeeded_commands=sum(
                    bool(x["succeeded"]) for x in self._step_results
                ),
                failed_commands=sum(not x["succeeded"] for x in self._step_results),
                requested_delay_sec=sum(
                    x.get("requested_delay_sec", 0) for x in self._step_results
                ),
                sandbox_create_started_at=self._create_started_at,
                sandbox_create_completed_at=self._create_completed_at,
                sandbox_create_sec=self._api_total("create"),
                first_command_started_at=self._first_command_started_at,
                last_command_completed_at=self._last_command_completed_at,
                sandbox_deleted_at=self._deleted_at,
                first_command_to_last_command_sec=self._duration(
                    self._first_command_started_monotonic,
                    self._last_command_completed_monotonic,
                ),
                delete_cleanup_sec=self._api_total("delete"),
                first_command_to_delete_sec=self._duration(
                    self._first_command_started_monotonic, self._deleted
                ),
            )
            if write_error is not None:
                if cancelled:
                    raise asyncio.CancelledError from write_error
                raise write_error
            write_json(self.output_dir / "replay-result.json", result)
            if result.get("cleanup_error"):
                self._event("error", f"Replay cleanup failed: {result['cleanup_error']}")
            if not result.get("error"):
                self._event("info" if result["succeeded"] else "error",
                            f"Replay completed succeeded={result['succeeded']} "
                            f"commands={result['commands']} failed_commands={result['failed_commands']} "
                            f"elapsed={result['elapsed_sec']:.3f}s")
        if cancelled:
            raise asyncio.CancelledError
        return result

    @staticmethod
    def _duration(start: float | None, end: float | None) -> float | None:
        return None if start is None or end is None else max(0.0, end - start)

    async def _dispatch_command(
        self, command: str, timeout_sec: int | None, *, operation: str = "command"
    ) -> Any:
        from e2b import CommandExitException, TimeoutException

        sandbox = self.sandbox
        if sandbox is None:
            raise RuntimeError("Sandbox is not available")

        async def start_command() -> Any:
            # An envd-side deadline can kill only the shell and orphan its
            # children.  Apply the command deadline locally instead, while
            # bounding the separate command-start request below.
            return await sandbox.commands.run(
                cmd=command,
                background=True,
                timeout=0,
                request_timeout=0,
                user="root",
            )

        try:
            handle = await asyncio.wait_for(
                self._api_call(operation + "_start", start_command()),
                timeout=self.options.request_timeout_sec,
            )
        except (asyncio.TimeoutError, TimeoutException) as exc:
            raise CommandStartUncertain("command start timed out without a process handle") from exc

        waiter = asyncio.create_task(handle.wait())

        async def close_waiter() -> None:
            try:
                await asyncio.wait_for(asyncio.shield(waiter), timeout=3)
            except asyncio.TimeoutError:
                waiter.cancel()
                try:
                    await waiter
                except asyncio.CancelledError:
                    pass
            except Exception:
                # SIGKILL usually yields CommandExitException; consume it.
                pass

        async def wait_command() -> Any:
            if timeout_sec:
                return await asyncio.wait_for(asyncio.shield(waiter), timeout=timeout_sec)
            return await waiter

        try:
            return await self._api_call(operation + "_wait", wait_command())
        except CommandExitException as exc:
            # Only a confirmed process exit is a business command failure.
            return exc
        except (asyncio.TimeoutError, TimeoutException) as exc:
            unexpected_stream_timeout = isinstance(exc, TimeoutException)
            # Resolve a completion that raced with the local timeout before
            # attempting to terminate a possibly reused PID.
            if not unexpected_stream_timeout and waiter.done():
                try:
                    return waiter.result()
                except CommandExitException as exit_exc:
                    return exit_exc
                except Exception as wait_exc:
                    unexpected_stream_timeout = True
                    exc = wait_exc
            try:
                cleanup = await self._api_call(
                    "command_tree_cleanup", terminate_command_tree(sandbox, handle.pid)
                )
                self._last_timeout_cleanup = cleanup
                self._event("warning", f"Timed-out command tree cleaned: {cleanup}")
            finally:
                await close_waiter()
            if unexpected_stream_timeout:
                raise CommandCleanupUncertain(
                    "command stream timed out before the local command deadline"
                ) from exc
            raise TimeoutError(
                f"Command result did not return within {timeout_sec}s"
            ) from exc

    async def _execute_step(
        self,
        step: ReplayStep,
        total_steps: int,
        job_total_steps: int,
    ) -> dict[str, Any]:
        from e2b import TimeoutException

        execution_action = normalize_str_replace_editor_action(step.action)
        command = wrap_action(
            execution_action,
            self.options.setup_command,
        )
        started_at = absolute_timestamp()
        self._job_event(
            "info",
            f"[{step.index + 1}/{job_total_steps}] COMMAND {step.action}",
            timestamp=started_at,
        )
        if execution_action != step.action:
            self._job_event(
                "info",
                f"[{step.index + 1}/{job_total_steps}] "
                "Normalized str_replace_editor boundary newlines",
                timestamp=started_at,
            )
        self._block(
            "\n"
            f"[{started_at}] [{step.index + 1}/{total_steps}] COMMAND START\n"
            f"{step.action}"
        )
        api_offset = len(self._api_timings)
        self._last_timeout_cleanup = None
        infrastructure_error = False
        timed_out = False
        failure_chain = []
        try:
            raw_result = await self._dispatch_command(
                command,
                self.options.command_timeout_sec,
            )
            stdout, stderr, return_code = result_fields(raw_result)
            if return_code is None:
                infrastructure_error = True
                raise RuntimeError("Command result is missing an exit code")
            succeeded = return_code == 0
        except Exception as exc:
            failure_chain = exception_chain(exc)
            stdout = ""
            stderr = f"{type(exc).__name__}: {exc}"
            return_code = None
            succeeded = False
            timed_out = isinstance(exc, (TimeoutError, TimeoutException))
            # Match replay-aenv: ordinary command exceptions are failed steps,
            # with continuation governed by stop_on_error. Recognized transient errors
            # and invalid replay results remain fatal; timeouts keep their policy.
            infrastructure_error = infrastructure_error or (
                isinstance(exc, (CommandCleanupUncertain, CommandStartUncertain))
                or (not timed_out and is_transient_sandbox_error(exc))
            )
        command_calls = [x for x in self._api_timings[api_offset:]
                         if x["operation"] in ("command_start", "command_wait")]
        # Do not include parsing, timeout cleanup/kill, warning logs or result writes.
        elapsed_sec = sum(x["elapsed_sec"] for x in command_calls)
        if command_calls:
            started_at = command_calls[0]["started_at"]
            completed_at = command_calls[-1]["completed_at"]
            if self._first_command_started_monotonic is None:
                self._first_command_started_at = started_at
                self._first_command_started_monotonic = command_calls[0]["started_monotonic"]
            self._last_command_completed_at = completed_at
            self._last_command_completed_monotonic = command_calls[-1]["completed_monotonic"]
        else:
            completed_at = absolute_timestamp()
        if timed_out:
            outcome = (
                "ignored; continuing with subsequent commands"
                if self.options.command_timeout_continue
                else "stopping replay because continuation is disabled"
            )
            self._job_event(
                "warning",
                f"[{step.index + 1}/{job_total_steps}] COMMAND TIMEOUT {outcome}",
            )

        self._job_event(
            "info",
            f"[{step.index + 1}/{job_total_steps}] RESULT "
            f"exit_code={return_code} succeeded={succeeded} elapsed={elapsed_sec:.3f}s",
            timestamp=completed_at,
        )
        self._block(
            "\n"
            f"[{completed_at}] [{step.index + 1}/{total_steps}] COMMAND END\n"
            f"exit_code: {return_code}\n"
            f"elapsed: {elapsed_sec:.3f}s\n"
            "stdout:\n"
            f"{stdout.rstrip() if stdout else '<empty>'}\n\n"
            "stderr:\n"
            f"{stderr.rstrip() if stderr else '<empty>'}"
        )
        result = {
            "index": step.index,
            "action": step.action,
            "execution_action": execution_action,
            "started_at": started_at,
            "completed_at": completed_at,
            "stdout": stdout,
            "stderr": stderr,
            "return_code": return_code,
            "elapsed_sec": elapsed_sec,
            "succeeded": succeeded,
            "timed_out": timed_out,
            "infrastructure_error": infrastructure_error,
        }
        if failure_chain:
            result["exception_chain"] = failure_chain
        if self._last_timeout_cleanup is not None:
            result["timeout_cleanup"] = self._last_timeout_cleanup
        return result


def is_transient_sandbox_error(exc: BaseException) -> bool:
    """Return whether a failed infrastructure request is safe to retry."""

    text = f"{type(exc).__name__}: {exc}".lower()
    return any(
        marker in text
        for marker in (
            "502:",
            "http 502",
            "bad gateway",
            "503:",
            "http 503",
            "service unavailable",
            "504:",
            "http 504",
            "gateway timeout",
            "429:",
            "http 429",
            "too many requests",
            "rate limit",
            "timed out",
            "timeout",
            "connection reset",
            "connection refused",
            "connection aborted",
            "temporarily unavailable",
        )
    )


def is_timeout_error(exc: BaseException) -> bool:
    """Return whether an exception represents a timeout."""

    text = f"{type(exc).__name__}: {exc}".lower()
    return "timeout" in text or "timed out" in text


def result_fields(raw_result: Any) -> tuple[str, str, int | None]:
    stdout = getattr(raw_result, "stdout", "")
    stderr = getattr(raw_result, "stderr", "")
    return_code = None
    for name in ("exit_code", "return_code", "exit_status", "code"):
        value = getattr(raw_result, name, None)
        if isinstance(value, int):
            return_code = value
            break
    return str(stdout or ""), str(stderr or ""), return_code
