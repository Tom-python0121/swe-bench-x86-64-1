"""Keep one RUNNING reservation throughout create, replay delays and deletion."""

from __future__ import annotations

import asyncio
import time
from typing import Any

from ...report.results import absolute_timestamp

from ..models import ReplayStep
from .sandbox import SandboxRunner


class ContinuousRunner(SandboxRunner):
    execution_mode = "continuous"

    async def _recover_created(self, matches: list[Any]) -> bool:
        # Reconnect only a sandbox positively identified by this task's create key.
        # It must already be running; continuous mode never intentionally resumes it.
        from e2b import AsyncSandbox

        self.sandbox_id = matches[0].sandbox_id
        state = getattr(matches[0], "state", None)
        if str(getattr(state, "value", state)).lower() != "running":
            raise RuntimeError(f"Create recovery sandbox {self.sandbox_id} is not running: {state}")
        for duplicate in matches[1:]:
            await asyncio.wait_for(
                self._api_call("create_cleanup_delete", AsyncSandbox.kill(duplicate.sandbox_id)),
                self.options.request_timeout_sec,
            )
        self.sandbox = await self._api_call("create_recovery_connect", AsyncSandbox.connect(
            self.sandbox_id,
            timeout=self.options.sandbox_timeout_sec,
            request_timeout=self.options.request_timeout_sec,
        ))
        self._create_state_uncertain = False
        self._event("warning", f"Reconnected existing running sandbox {self.sandbox_id} after lost create response")
        return True

    async def _initialize(self) -> None:
        pass

    async def _run_step(
        self, step: ReplayStep, total: int, trajectory_total: int
    ) -> dict[str, Any]:
        started_at = absolute_timestamp()
        started = time.perf_counter()
        await asyncio.sleep(step.delay_time_sec)
        waited = time.perf_counter() - started
        completed_at = absolute_timestamp()
        result = await self._execute_step(step, total, trajectory_total)
        self._step_results.append(result)
        result.update(
            trajectory_delay_sec=step.delay_time_sec,
            requested_delay_sec=step.delay_time_sec,
            delay_wait_started_at=started_at,
            delay_wait_completed_at=completed_at,
            delay_wait_sec=waited,
            command_sec=result["elapsed_sec"],
            interaction_total_sec=waited + result["elapsed_sec"],
        )
        timing_message = (
            f"Agent interaction timing step={step.index + 1}/{trajectory_total} "
            f"delay={step.delay_time_sec:.3f}s delay_wait={waited:.3f}s "
            f"command={result['command_sec']:.3f}s total={result['interaction_total_sec']:.3f}s"
        )
        self._job_event("info", timing_message, timestamp=result["completed_at"])
        self._block(timing_message)
        return result
