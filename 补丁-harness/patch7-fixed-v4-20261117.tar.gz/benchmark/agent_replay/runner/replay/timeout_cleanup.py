"""Bounded cleanup for a timed-out command in one owned AgentENV sandbox."""
import asyncio
import re


class CommandCleanupUncertain(RuntimeError):
    """The command's process tree could not be confirmed stopped."""


class CommandStartUncertain(RuntimeError):
    """A command start timed out without a usable process handle."""


_SCRIPT = r'''set -u
root=@@PID@@
declare -A birth
declare -a order
read_stat() {
  local line
  [[ -r /proc/$1/stat ]] || return 1
  IFS= read -r line < "/proc/$1/stat" || return 1
  line=${line##*) }
  read -r -a fields <<< "$line"
  [[ ${#fields[@]} -ge 20 ]] || return 1
}
if ! read_stat "$root" || [[ ${fields[0]} == Z ]]; then
  printf 'AWBS_ROOT_GONE pid=%s\n' "$root"
  exit 21
fi
birth[$root]=${fields[19]}
order=("$root")
if ! kill -STOP "$root" 2>/dev/null; then
  printf 'AWBS_STOP_FAILED pid=%s\n' "$root"
  exit 22
fi
stable=0
for ((round=0; round<64; round++)); do
  added=0
  for path in /proc/[0-9]*; do
    pid=${path##*/}
    [[ -n ${birth[$pid]+x} ]] && continue
    read_stat "$pid" || continue
    parent=${fields[1]}
    born=${fields[19]}
    [[ -n ${birth[$parent]+x} ]] || continue
    [[ ${fields[0]} == Z ]] && continue
    if kill -STOP "$pid" 2>/dev/null; then
      if read_stat "$pid" && [[ ${fields[19]} == "$born" ]]; then
        birth[$pid]=$born
        order+=("$pid")
        ((added+=1))
      fi
    fi
  done
  if ((added == 0)); then stable=1; break; fi
  if ((${#order[@]} > 4096)); then break; fi
done
failure=0
for ((i=${#order[@]}-1; i>=0; i--)); do
  pid=${order[$i]}
  if read_stat "$pid" && [[ ${fields[19]} == "${birth[$pid]}" ]] && [[ ${fields[0]} != Z ]]; then
    if ! kill -KILL "$pid" 2>/dev/null; then
      if read_stat "$pid" && [[ ${fields[19]} == "${birth[$pid]}" ]] && [[ ${fields[0]} != Z ]]; then
        failure=1
      fi
    fi
  fi
done
for ((attempt=0; attempt<50; attempt++)); do
  live=0
  for pid in "${order[@]}"; do
    if read_stat "$pid" && [[ ${fields[19]} == "${birth[$pid]}" ]] && [[ ${fields[0]} != Z ]]; then
      ((live+=1))
    fi
  done
  ((live == 0)) && break
  sleep 0.1
done
printf 'AWBS_TREE_CLEANUP root=%s tracked=%s live=%s stable=%s kill_error=%s\n' "$root" "${#order[@]}" "$live" "$stable" "$failure"
((live == 0 && stable == 1 && failure == 0)) || exit 23
'''


async def terminate_command_tree(sandbox, pid):
    if not isinstance(pid, int) or isinstance(pid, bool) or pid < 3:
        raise CommandCleanupUncertain('invalid command PID')
    command = _SCRIPT.replace('@@PID@@', str(pid))
    try:
        result = await asyncio.wait_for(
            sandbox.commands.run(command, timeout=20, request_timeout=20, user='root'),
            timeout=25,
        )
    except Exception as exc:
        detail = str(exc)[:300]
        raise CommandCleanupUncertain(f'process-tree cleanup failed for pid {pid}: {detail}') from exc
    text = result.stdout or ''
    match = re.search(r'AWBS_TREE_CLEANUP root=(\d+) tracked=(\d+) live=(\d+) stable=(\d+) kill_error=(\d+)', text)
    if (result.exit_code != 0 or not match or int(match.group(1)) != pid
            or int(match.group(3)) != 0 or int(match.group(4)) != 1 or int(match.group(5)) != 0):
        raise CommandCleanupUncertain(f'process-tree cleanup was not confirmed for pid {pid}: {text[-300:]}')
    return {'root_pid': pid, 'tracked_processes': int(match.group(2)), 'live_processes': 0}
